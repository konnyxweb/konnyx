/* ============================================================
   Konnyx — lógica principal (ES Module)
   ============================================================ */
import { initAnimations, animateFilter } from './animations.js';

/* ---------- CONFIGURACIÓN: edita estos datos ---------- */
const CONFIG = {
  whatsappNumber: '580000000000', // formato internacional, sin "+" ni espacios (placeholder)
  email: 'hola@konnyx.com'        // confirma tu correo real
};

/* ---------- Año del footer ---------- */
const yearEl = document.getElementById('year');
if (yearEl) yearEl.textContent = new Date().getFullYear();

/* ---------- Enlaces directos de contacto ---------- */
const waLink = document.getElementById('link-whatsapp');
const mailLink = document.getElementById('link-email');
if (waLink) waLink.href = `https://wa.me/${CONFIG.whatsappNumber}`;
if (mailLink) {
  mailLink.href = `mailto:${CONFIG.email}`;
  mailLink.textContent = CONFIG.email;
}

/* ---------- Menú móvil ---------- */
const toggle = document.getElementById('menu-toggle');
const menu = document.getElementById('mobile-menu');
const iconOpen = document.getElementById('icon-open');
const iconClose = document.getElementById('icon-close');

function setMenu(open) {
  if (!toggle || !menu) return;
  toggle.setAttribute('aria-expanded', String(open));
  toggle.setAttribute('aria-label', open ? 'Cerrar menú' : 'Abrir menú');
  menu.classList.toggle('hidden', !open);
  iconOpen?.classList.toggle('hidden', open);
  iconClose?.classList.toggle('hidden', !open);
}
toggle?.addEventListener('click', () => setMenu(toggle.getAttribute('aria-expanded') !== 'true'));
menu?.querySelectorAll('a').forEach((a) => a.addEventListener('click', () => setMenu(false)));
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') setMenu(false); });
window.matchMedia('(min-width: 768px)').addEventListener('change', (e) => { if (e.matches) setMenu(false); });

/* ---------- Enlace activo según la sección visible ---------- */
const navLinks = [...document.querySelectorAll('.nav-link')];
const sections = navLinks
  .map((a) => document.querySelector(a.getAttribute('href')))
  .filter(Boolean);

if ('IntersectionObserver' in window && sections.length) {
  const io = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        navLinks.forEach((a) => {
          a.toggleAttribute('aria-current', false);
          a.removeAttribute('aria-current');
        });
        const active = navLinks.find((a) => a.getAttribute('href') === `#${entry.target.id}`);
        active?.setAttribute('aria-current', 'true');
      });
    },
    { rootMargin: '-45% 0px -50% 0px' }
  );
  sections.forEach((s) => io.observe(s));
}

/* ---------- Filtro de proyectos ---------- */
const filterButtons = [...document.querySelectorAll('.filter-btn')];
const projects = [...document.querySelectorAll('.project')];

filterButtons.forEach((btn) => {
  btn.addEventListener('click', () => {
    const filter = btn.dataset.filter;
    filterButtons.forEach((b) => b.setAttribute('aria-pressed', String(b === btn)));

    const visible = [];
    projects.forEach((p) => {
      const show = filter === 'all' || p.dataset.category === filter;
      p.hidden = !show;
      if (show) visible.push(p);
    });
    animateFilter(visible);
  });
});

/* ---------- CTAs de pilares: preseleccionan el servicio ---------- */
const serviceSelect = document.getElementById('servicio');
document.querySelectorAll('[data-service]').forEach((a) => {
  a.addEventListener('click', () => {
    if (!serviceSelect) return;
    const opt = [...serviceSelect.options].find((o) => o.dataset.key === a.dataset.service);
    if (opt) serviceSelect.value = opt.value;
  });
});

/* ---------- Formulario estático: arma el mensaje y abre WhatsApp / correo ---------- */
const form = document.getElementById('contact-form');
const statusEl = document.getElementById('form-status');

form?.addEventListener('submit', (e) => {
  e.preventDefault();
  const channel = e.submitter?.dataset.channel || 'whatsapp';
  const data = new FormData(form);
  const nombre = String(data.get('nombre') || '').trim();
  const email = String(data.get('email') || '').trim();
  const servicio = String(data.get('servicio') || '');
  const mensaje = String(data.get('mensaje') || '').trim();

  // Validación mínima y accesible
  let valid = true;
  ['nombre', 'mensaje'].forEach((id) => {
    const el = document.getElementById(id);
    const empty = !el.value.trim();
    el.setAttribute('aria-invalid', String(empty));
    if (empty) valid = false;
  });
  if (!valid) {
    statusEl.textContent = 'Por favor completa tu nombre y cuéntame de tu proyecto.';
    statusEl.classList.replace('text-volt', 'text-coral');
    return;
  }
  statusEl.classList.replace('text-coral', 'text-volt');

  const body =
    `Hola Konnyx, soy ${nombre}.\n` +
    `Me interesa: ${servicio}.\n\n${mensaje}` +
    (email ? `\n\nMi correo: ${email}` : '');

  if (channel === 'email') {
    const subject = encodeURIComponent(`Proyecto de ${servicio} — ${nombre}`);
    window.location.href = `mailto:${CONFIG.email}?subject=${subject}&body=${encodeURIComponent(body)}`;
    statusEl.textContent = 'Abriendo tu app de correo…';
  } else {
    window.open(`https://wa.me/${CONFIG.whatsappNumber}?text=${encodeURIComponent(body)}`, '_blank', 'noopener');
    statusEl.textContent = 'Abriendo WhatsApp…';
  }
});

/* ---------- Animaciones ---------- */
initAnimations();

/* ============================================================
   Konnyx — animaciones GSAP + ScrollTrigger
   - Reversibles: responden al bajar y al subir el scroll.
   - Los elementos son VISIBLES por defecto en CSS; GSAP solo los
     oculta al construir las animaciones, así nada queda atascado
     en opacity:0 si el script falla o el usuario navega rápido.
   - Respeta prefers-reduced-motion (no se crea ninguna animación).
   ============================================================ */

const REDUCE_QUERY = '(prefers-reduced-motion: reduce)';
const prefersReduced = () => window.matchMedia(REDUCE_QUERY).matches;

let ctx = null;

export function initAnimations() {
  const { gsap, ScrollTrigger } = window;
  if (!gsap || !ScrollTrigger) return; // CDN no cargó: el sitio sigue siendo legible

  gsap.registerPlugin(ScrollTrigger);
  ScrollTrigger.config({ ignoreMobileResize: true });

  const mm = gsap.matchMedia();

  mm.add('(prefers-reduced-motion: no-preference)', () => {
    ctx = gsap.context(() => buildAnimations(gsap, ScrollTrigger), document.body);
    // matchMedia revierte el contexto automáticamente si el usuario activa "reducir movimiento"
    return () => ctx && ctx.revert();
  });

  // Recalcular posiciones cuando cambian fuentes e imágenes
  const refresh = () => ScrollTrigger.refresh();
  window.addEventListener('load', refresh);
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(refresh);
  document.querySelectorAll('img').forEach((img) => {
    if (!img.complete) img.addEventListener('load', refresh, { once: true });
  });
}

function buildAnimations(gsap, ScrollTrigger) {
  /* ---------- Hero (carga inicial) ---------- */
  const intro = gsap.timeline({ defaults: { ease: 'power3.out' } });
  intro
    .from('.hero-line', { yPercent: 110, duration: 1, stagger: 0.12 })
    .from('[data-hero-fade]', { y: 24, opacity: 0, duration: 0.8, stagger: 0.1 }, '-=0.6');

  /* ---------- Parallax del hero (scrub: sube y baja) ---------- */
  gsap.utils.toArray('[data-parallax]').forEach((el) => {
    gsap.to(el, {
      yPercent: Number(el.dataset.parallax) * 4,
      ease: 'none',
      scrollTrigger: { trigger: '#inicio', start: 'top top', end: 'bottom top', scrub: 0.6 }
    });
  });

  /* ---------- Marquee ligado al scroll ---------- */
  const marquee = document.querySelector('[data-marquee]');
  if (marquee) {
    gsap.fromTo(
      marquee,
      { xPercent: 0 },
      {
        xPercent: -35,
        ease: 'none',
        scrollTrigger: { trigger: marquee, start: 'top bottom', end: 'bottom top', scrub: 0.6 }
      }
    );
  }

  /* ---------- Reveals reversibles ----------
     play: al entrar bajando. reverse: al volver a subir por encima del punto de inicio.
     Al salir por arriba el elemento queda visible (no se oculta lo ya visto). */
  gsap.utils.toArray('[data-reveal]').forEach((el) => {
    const dir = el.dataset.reveal;
    const from = { opacity: 0, duration: 0.9, ease: 'power3.out' };
    if (dir === 'left') from.x = -60;
    else if (dir === 'right') from.x = 60;
    else from.y = 40;

    gsap.from(el, {
      ...from,
      scrollTrigger: {
        trigger: el,
        start: 'top 88%',
        toggleActions: 'play none none reverse',
        invalidateOnRefresh: true
      }
    });
  });

  /* ---------- Línea de progreso del proceso (scrub bidireccional) ---------- */
  const progress = document.querySelector('[data-progress]');
  if (progress) {
    gsap.fromTo(
      progress,
      { scaleY: 0 },
      {
        scaleY: 1,
        ease: 'none',
        scrollTrigger: { trigger: '#proceso-list', start: 'top 70%', end: 'bottom 70%', scrub: 0.4 }
      }
    );
  }

  /* ---------- Navbar: se oculta al bajar y reaparece al subir ---------- */
  const navbar = document.getElementById('navbar');
  if (navbar) {
    const showNav = gsap.to(navbar, { yPercent: -100, duration: 0.35, ease: 'power2.out', paused: true });
    ScrollTrigger.create({
      start: 0,
      end: 'max',
      onUpdate: (self) => {
        const menuOpen = document.getElementById('menu-toggle')?.getAttribute('aria-expanded') === 'true';
        if (self.direction === 1 && self.scroll() > 140 && !menuOpen) showNav.play();
        else showNav.reverse();
      }
    });
    // Si el foco entra al navbar con teclado, mostrarlo
    navbar.addEventListener('focusin', () => showNav.reverse());
  }
}

/* ---------- Animación al filtrar proyectos ---------- */
export function animateFilter(items) {
  const { gsap, ScrollTrigger } = window;
  if (!gsap || prefersReduced() || !items.length) {
    if (ScrollTrigger) ScrollTrigger.refresh();
    return;
  }
  gsap.fromTo(
    items,
    { opacity: 0, y: 24, scale: 0.98 },
    {
      opacity: 1, y: 0, scale: 1,
      duration: 0.5, stagger: 0.07, ease: 'power2.out',
      clearProps: 'opacity,transform', // nunca dejar estilos inline atascados
      onComplete: () => ScrollTrigger && ScrollTrigger.refresh()
    }
  );
}
